//
//  ytcpsocket.h
//  YeelightController
//
//  Created by Alessandro Pagiaro on 05/02/17.
//  Copyright © 2017 Alessandro Pagiaro. All rights reserved.
//

#ifndef ytcpsocket_h
#define ytcpsocket_h

#include <stdio.h>

#endif /* ytcpsocket_h */
